package com.waruna;

public class SavingsAccount extends Account {
}
