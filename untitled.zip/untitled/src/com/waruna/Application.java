package com.waruna;

public class Application {

    public static void main(String[] args) {
	// write your code here
        CreditCard creditCard = new CreditCard();
        creditCard.withdraw(1000.0);
    }
}
