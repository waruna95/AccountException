package com.waruna;

public class MasterCard extends CreditAccount {
}
