package com.waruna;

public class CurrentAccount extends Account {
}
