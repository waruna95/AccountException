package com.waruna;

public class DebitCard extends VisaCard {
}
